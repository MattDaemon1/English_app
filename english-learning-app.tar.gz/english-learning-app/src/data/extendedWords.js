// Base de données étendue avec plus de mots anglais courants
export const extendedWordsData = [
  // Mots de base (niveau débutant)
  {
    id: 21,
    word: "house",
    translation: "maison",
    pronunciation: "/haʊs/",
    partOfSpeech: "noun",
    definition: "Bâtiment où vivent des personnes",
    example: "I live in a big house.",
    exampleTranslation: "Je vis dans une grande maison.",
    difficulty: "beginner",
    category: "home"
  },
  {
    id: 22,
    word: "water",
    translation: "eau",
    pronunciation: "/ˈwɔːtər/",
    partOfSpeech: "noun",
    definition: "Liquide transparent et incolore",
    example: "I drink water every day.",
    exampleTranslation: "Je bois de l'eau tous les jours.",
    difficulty: "beginner",
    category: "food"
  },
  {
    id: 23,
    word: "food",
    translation: "nourriture",
    pronunciation: "/fuːd/",
    partOfSpeech: "noun",
    definition: "Substances consommées pour la nutrition",
    example: "This food is delicious.",
    exampleTranslation: "Cette nourriture est délicieuse.",
    difficulty: "beginner",
    category: "food"
  },
  {
    id: 24,
    word: "school",
    translation: "école",
    pronunciation: "/skuːl/",
    partOfSpeech: "noun",
    definition: "Institution d'enseignement",
    example: "Children go to school to learn.",
    exampleTranslation: "Les enfants vont à l'école pour apprendre.",
    difficulty: "beginner",
    category: "education"
  },
  {
    id: 25,
    word: "work",
    translation: "travail",
    pronunciation: "/wɜːrk/",
    partOfSpeech: "noun/verb",
    definition: "Activité professionnelle ou effort",
    example: "I work in an office.",
    exampleTranslation: "Je travaille dans un bureau.",
    difficulty: "beginner",
    category: "work"
  },

  // Mots intermédiaires
  {
    id: 26,
    word: "develop",
    translation: "développer",
    pronunciation: "/dɪˈveləp/",
    partOfSpeech: "verb",
    definition: "Faire croître ou progresser",
    example: "We need to develop new skills.",
    exampleTranslation: "Nous devons développer de nouvelles compétences.",
    difficulty: "intermediate",
    category: "business"
  },
  {
    id: 27,
    word: "business",
    translation: "entreprise",
    pronunciation: "/ˈbɪznəs/",
    partOfSpeech: "noun",
    definition: "Activité commerciale ou économique",
    example: "She runs her own business.",
    exampleTranslation: "Elle dirige sa propre entreprise.",
    difficulty: "intermediate",
    category: "business"
  },
  {
    id: 28,
    word: "decision",
    translation: "décision",
    pronunciation: "/dɪˈsɪʒən/",
    partOfSpeech: "noun",
    definition: "Choix fait après réflexion",
    example: "It was a difficult decision.",
    exampleTranslation: "C'était une décision difficile.",
    difficulty: "intermediate",
    category: "abstract"
  },
  {
    id: 29,
    word: "information",
    translation: "information",
    pronunciation: "/ˌɪnfərˈmeɪʃən/",
    partOfSpeech: "noun",
    definition: "Données ou connaissances communiquées",
    example: "I need more information about this topic.",
    exampleTranslation: "J'ai besoin de plus d'informations sur ce sujet.",
    difficulty: "intermediate",
    category: "communication"
  },
  {
    id: 30,
    word: "problem",
    translation: "problème",
    pronunciation: "/ˈprɑːbləm/",
    partOfSpeech: "noun",
    definition: "Situation difficile à résoudre",
    example: "We have a problem to solve.",
    exampleTranslation: "Nous avons un problème à résoudre.",
    difficulty: "intermediate",
    category: "abstract"
  },

  // Mots avancés
  {
    id: 31,
    word: "responsibility",
    translation: "responsabilité",
    pronunciation: "/rɪˌspɑːnsəˈbɪləti/",
    partOfSpeech: "noun",
    definition: "Obligation de répondre de ses actes",
    example: "Leadership comes with great responsibility.",
    exampleTranslation: "Le leadership s'accompagne d'une grande responsabilité.",
    difficulty: "advanced",
    category: "abstract"
  },
  {
    id: 32,
    word: "organization",
    translation: "organisation",
    pronunciation: "/ˌɔːrɡənəˈzeɪʃən/",
    partOfSpeech: "noun",
    definition: "Structure ou arrangement systématique",
    example: "The organization helps local communities.",
    exampleTranslation: "L'organisation aide les communautés locales.",
    difficulty: "advanced",
    category: "business"
  },
  {
    id: 33,
    word: "development",
    translation: "développement",
    pronunciation: "/dɪˈveləpmənt/",
    partOfSpeech: "noun",
    definition: "Processus de croissance ou d'amélioration",
    example: "The development of new technology is exciting.",
    exampleTranslation: "Le développement de nouvelles technologies est passionnant.",
    difficulty: "advanced",
    category: "science"
  },
  {
    id: 34,
    word: "relationship",
    translation: "relation",
    pronunciation: "/rɪˈleɪʃənʃɪp/",
    partOfSpeech: "noun",
    definition: "Connexion entre personnes ou choses",
    example: "They have a strong relationship.",
    exampleTranslation: "Ils ont une relation solide.",
    difficulty: "advanced",
    category: "relationships"
  },
  {
    id: 35,
    word: "management",
    translation: "gestion",
    pronunciation: "/ˈmænɪdʒmənt/",
    partOfSpeech: "noun",
    definition: "Administration ou contrôle d'une organisation",
    example: "Good management is essential for success.",
    exampleTranslation: "Une bonne gestion est essentielle au succès.",
    difficulty: "advanced",
    category: "business"
  },

  // Mots du quotidien
  {
    id: 36,
    word: "morning",
    translation: "matin",
    pronunciation: "/ˈmɔːrnɪŋ/",
    partOfSpeech: "noun",
    definition: "Première partie de la journée",
    example: "Good morning! How are you?",
    exampleTranslation: "Bonjour ! Comment allez-vous ?",
    difficulty: "beginner",
    category: "time"
  },
  {
    id: 37,
    word: "evening",
    translation: "soir",
    pronunciation: "/ˈiːvnɪŋ/",
    partOfSpeech: "noun",
    definition: "Fin de journée avant la nuit",
    example: "We have dinner in the evening.",
    exampleTranslation: "Nous dînons le soir.",
    difficulty: "beginner",
    category: "time"
  },
  {
    id: 38,
    word: "weather",
    translation: "temps (météo)",
    pronunciation: "/ˈweðər/",
    partOfSpeech: "noun",
    definition: "Conditions atmosphériques",
    example: "The weather is nice today.",
    exampleTranslation: "Il fait beau aujourd'hui.",
    difficulty: "beginner",
    category: "nature"
  },
  {
    id: 39,
    word: "money",
    translation: "argent",
    pronunciation: "/ˈmʌni/",
    partOfSpeech: "noun",
    definition: "Moyen d'échange économique",
    example: "I need to save money for vacation.",
    exampleTranslation: "Je dois économiser de l'argent pour les vacances.",
    difficulty: "beginner",
    category: "finance"
  },
  {
    id: 40,
    word: "computer",
    translation: "ordinateur",
    pronunciation: "/kəmˈpjuːtər/",
    partOfSpeech: "noun",
    definition: "Machine électronique de traitement de données",
    example: "I use my computer for work.",
    exampleTranslation: "J'utilise mon ordinateur pour le travail.",
    difficulty: "intermediate",
    category: "technology"
  }
];

// Conversations étendues pour différents niveaux
export const extendedConversations = [
  {
    id: 'hotel_checkin',
    name: 'Enregistrement à l\'hôtel',
    context: 'Vous arrivez à votre hôtel et devez vous enregistrer',
    difficulty: 'intermediate',
    steps: [
      {
        speaker: 'receptionist',
        english: 'Good evening! Welcome to our hotel. How can I help you?',
        french: 'Bonsoir ! Bienvenue dans notre hôtel. Comment puis-je vous aider ?',
        audio: true
      },
      {
        speaker: 'guest',
        english: 'Hello, I have a reservation under the name Smith.',
        french: 'Bonjour, j\'ai une réservation au nom de Smith.',
        userInput: true
      },
      {
        speaker: 'receptionist',
        english: 'Let me check... Yes, here it is. A double room for three nights?',
        french: 'Laissez-moi vérifier... Oui, la voici. Une chambre double pour trois nuits ?',
        audio: true
      },
      {
        speaker: 'guest',
        english: 'That\'s correct. What time is breakfast served?',
        french: 'C\'est exact. À quelle heure le petit-déjeuner est-il servi ?',
        userInput: true
      },
      {
        speaker: 'receptionist',
        english: 'Breakfast is served from 7 AM to 10 AM in the dining room.',
        french: 'Le petit-déjeuner est servi de 7h à 10h dans la salle à manger.',
        audio: true
      }
    ]
  },
  {
    id: 'job_interview',
    name: 'Entretien d\'embauche',
    context: 'Vous passez un entretien pour un poste',
    difficulty: 'advanced',
    steps: [
      {
        speaker: 'interviewer',
        english: 'Thank you for coming today. Please tell me about yourself.',
        french: 'Merci d\'être venu aujourd\'hui. Parlez-moi de vous.',
        audio: true
      },
      {
        speaker: 'candidate',
        english: 'I have five years of experience in marketing and I\'m passionate about digital strategies.',
        french: 'J\'ai cinq ans d\'expérience en marketing et je suis passionné par les stratégies numériques.',
        userInput: true
      },
      {
        speaker: 'interviewer',
        english: 'What are your greatest strengths?',
        french: 'Quelles sont vos plus grandes forces ?',
        audio: true
      },
      {
        speaker: 'candidate',
        english: 'I\'m very organized and I work well under pressure.',
        french: 'Je suis très organisé et je travaille bien sous pression.',
        userInput: true
      }
    ]
  },
  {
    id: 'doctor_visit',
    name: 'Visite chez le médecin',
    context: 'Vous consultez un médecin pour un problème de santé',
    difficulty: 'intermediate',
    steps: [
      {
        speaker: 'doctor',
        english: 'Good morning. What brings you here today?',
        french: 'Bonjour. Qu\'est-ce qui vous amène ici aujourd\'hui ?',
        audio: true
      },
      {
        speaker: 'patient',
        english: 'I\'ve been having headaches for the past week.',
        french: 'J\'ai des maux de tête depuis une semaine.',
        userInput: true
      },
      {
        speaker: 'doctor',
        english: 'How often do you get these headaches?',
        french: 'À quelle fréquence avez-vous ces maux de tête ?',
        audio: true
      },
      {
        speaker: 'patient',
        english: 'Almost every day, especially in the afternoon.',
        french: 'Presque tous les jours, surtout l\'après-midi.',
        userInput: true
      }
    ]
  }
];

// Exercices spécialisés
export const specializedExercises = [
  {
    type: 'pronunciation',
    name: 'Exercice de prononciation',
    description: 'Pratiquez la prononciation des sons difficiles',
    words: [
      { word: 'thought', phonetic: '/θɔːt/', difficulty: 'th sound' },
      { word: 'through', phonetic: '/θruː/', difficulty: 'th sound' },
      { word: 'world', phonetic: '/wɜːrld/', difficulty: 'r sound' },
      { word: 'work', phonetic: '/wɜːrk/', difficulty: 'r sound' }
    ]
  },
  {
    type: 'grammar',
    name: 'Exercice de grammaire',
    description: 'Pratiquez les structures grammaticales',
    exercises: [
      {
        sentence: 'I _____ to the store yesterday.',
        options: ['go', 'went', 'going', 'gone'],
        correct: 'went',
        explanation: 'Past tense of "go" is "went"'
      },
      {
        sentence: 'She _____ working here for five years.',
        options: ['has been', 'have been', 'is', 'was'],
        correct: 'has been',
        explanation: 'Present perfect continuous for duration'
      }
    ]
  }
];

// Thèmes de vocabulaire
export const vocabularyThemes = [
  {
    theme: 'travel',
    name: 'Voyage',
    words: ['airport', 'passport', 'luggage', 'ticket', 'hotel', 'vacation'],
    level: 'intermediate'
  },
  {
    theme: 'technology',
    name: 'Technologie',
    words: ['computer', 'internet', 'software', 'application', 'digital', 'online'],
    level: 'intermediate'
  },
  {
    theme: 'emotions',
    name: 'Émotions',
    words: ['happy', 'sad', 'angry', 'excited', 'nervous', 'calm'],
    level: 'beginner'
  },
  {
    theme: 'business',
    name: 'Affaires',
    words: ['meeting', 'presentation', 'deadline', 'project', 'client', 'profit'],
    level: 'advanced'
  }
];

